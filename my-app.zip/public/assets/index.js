import img1 from "./Group 2017.png";
import img2 from "./Group 2021.png";
import img3 from "./Group 2012.png";
import Ellipse from "./Ellipse 165.png";
import Ellipse1 from "./Ellipse 166.png";
import Ellipse2 from "./Ellipse 167.png";
import Ellipse3 from "./Ellipse 168.png";
import Ellipse4 from "./Ellipse 169.png";
import Ellipse5 from "./Ellipse 170.png";
import Ellipse6 from "./Ellipse 171.png";
import Ellipse7 from "./Ellipse 172.png";
import Ellipse8 from "./Ellipse 173.png";
import I from "./i.png";

export {
    img1,
    img2,
    img3,
    Ellipse,
    Ellipse1,
    Ellipse2,
    Ellipse3,
    Ellipse4,
    Ellipse5,
    Ellipse6,
    Ellipse7,
    Ellipse8,
    I,
}